package com.company;

public abstract class Student {
    public void takeXam(){
        System.out.println("Taking Xam!");
    }

}
