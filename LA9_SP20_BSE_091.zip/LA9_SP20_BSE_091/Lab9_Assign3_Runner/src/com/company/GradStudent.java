package com.company;

public class GradStudent extends Student {
    @Override
    public void takeXam(){
        System.out.println("Giving Written paper!");
    }
}
