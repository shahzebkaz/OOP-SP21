package com.company;

public class Main {

    public static void main(String[] args) {
        ChildClock time=new ChildClock("16","45","15");
        time.display();
    }

}
